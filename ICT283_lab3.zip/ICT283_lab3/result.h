#ifndef RESULT_H
#define RESULT_H

#include "unit.h"
#include <iostream>

/**
 * @class Result
 * @brief Stores a unit and its mark.
 */
class Result
{
public:
    /// Initialise a result with an empty unit and zero mark.
    Result();

    /**
     * @brief Set the unit.
     * @param unit Unit to store.
     */
    void SetUnit(const Unit & unit);

    /**
     * @brief Get the unit.
     * @return Read-only reference to the stored unit.
     */
    const Unit & GetUnit() const;

    /**
     * @brief Set the mark.
     * @param mark Mark obtained for the unit.
     */
    void SetMark(float mark);

    /**
     * @brief Get the mark.
     * @return Stored mark.
     */
    float GetMark() const;

private:
    Unit m_unit;  ///< Unit associated with the result.
    float m_mark; ///< Mark obtained for the unit.
};

/**
 * @brief Read unit information and its mark.
 * @param input Input stream.
 * @param result Result to populate.
 * @return Input stream.
 */
std::istream & operator >>(std::istream & input, Result & result);

/**
 * @brief Write unit information and its mark.
 * @param os Output stream.
 * @param result Result to display.
 * @return Output stream.
 */
std::ostream & operator <<(std::ostream & os, const Result & result);

#endif
