// COURSE.CPP - Unit class implementation

#include "unit.h"

#include <string.h>  // C string library needed here for the C string routines.
                     // revise your ict159 work if forgotten.

Unit::Unit()
{
  name[0] = '\0';// it is a char * string, not a C++ string object.
  id[0] = '\0';
  credits = 0;

}

Unit::Unit( const char * nam, const char * unitId,
                unsigned cred )
{
  strncpy( name, nam, CourseNameSize - 1);  //strncpy needed from string.h
  name[CourseNameSize - 1] = '\0';

  strncpy(id, unitId, sizeof(id) - 1);
  id[sizeof(id) - 1] = '\0';

  credits = cred;
}


// The following routine does not belong to the Unit class, so it is NOT a method
// You can see that the prefix Unit:: isn't there.
// So it is general routine, just a function that you would have learnt in
// ict159, but this one has an unusual name.
const char * Unit::GetName() const
{
    return name;
}

unsigned Unit::GetCredits() const
{
    return credits;
}

void Unit::SetCredits(unsigned cred)
{
    credits = cred;
}

void Unit::SetName(const char * nam)
{
    strncpy(name, nam, CourseNameSize - 1);
    name[CourseNameSize - 1] = '\0';
}

const char * Unit::GetId() const
{
    return id;
}

void Unit::SetId(const char * unitId)
{
    strncpy(id, unitId, sizeof(id) - 1);
    id[sizeof(id) - 1] = '\0';
}

istream & operator >>( istream & input, Unit & C )
{
  input >> C.id >> C.name >> C.credits;
  return input;
}


// The following routine does not belong to the Unit class, so it is NOT a method
// You can see that the prefix Unit:: isn't there.
// So it is general routine, just a function that you would have learnt in
// ict159, but this one has an unusual name.
ostream & operator <<( ostream & os, const Unit & C )
{
  os << "  Unit ID:  " << C.id << '\n'
     << "  Unit Name: " << C.name << '\n'
     << "  Credits: " << C.credits << '\n';
  return os;
}
