
#include "result.h"

Result::Result()
{
    m_mark = 0.0f;
}

void Result::SetUnit(const Unit & unit)
{
    m_unit = unit;
}

const Unit & Result::GetUnit() const
{
    return m_unit;
}

void Result::SetMark(float mark)
{
    m_mark = mark;
}

float Result::GetMark() const
{
    return m_mark;
}

std::istream & operator >>(std::istream & input, Result & result)
{
    Unit unit;
    float mark = 0.0f;

    if (input >> unit >> mark)
    {
        result.SetUnit(unit);
        result.SetMark(mark);
    }

    return input;
}

std::ostream & operator <<(std::ostream & os, const Result & result)
{
    os << result.GetUnit()
       << "  Marks: " << result.GetMark() << '\n';

    return os;
}
