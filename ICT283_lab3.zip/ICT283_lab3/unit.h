// COURSE.H - Unit class definition/interface
// author KRI
// modified smr

// A .h file is also known as the header file. It is the Interface.
// It should only contain type declarations and prototypes of routines, similar
// to what was done in ict159.

// The implementation will go into the corresponding .cpp file. Implementation is the
// body of the routines.

#ifndef COURSE_H
#define COURSE_H

#include <iostream>

// No routine from string.h is needed in this header file course.h.
// So it has been commented out.
// Do not #include files that are not needed.
// The implementation file course.cpp needs string.h, so #include there

// #include <string.h>  // C string library, DO NOT INCLUDE HEADER FILES IF NOT NEEDED HERE

// Is iostream needed in this  file. Easy to check by commenting out the line #include <iostream>

using namespace std;


// Although the usage of unsigned here is fine, usage of unsigned type can be problematic.
// Can you think of what problems can occur?

const unsigned CourseNameSize = 100;

/**
 * @class Unit
 * @brief Stores a unit's name, ID and credits.
 */
class Unit {
public:

/**
 * @brief Initialise an empty unit with zero credits.
 */
Unit();

/**
 * @brief Initialise a unit with a name, ID and credits.
 * @param nam Unit name.
 * @param unitId Unit identifier, such as ICT283.
 * @param cred Number of credits.
 */
Unit(const char * nam, const char * unitId, unsigned cred);

/**
 * @brief Get the number of credits.
 * @return Unit credits.
 */
unsigned GetCredits() const;

/**
 * @brief Set the number of credits.
 * @param cred Number of credits.
 */
void SetCredits(unsigned cred);

/**
 * @brief Get the unit name.
 * @return Read-only pointer to the stored name.
 */
const char * GetName() const;

/**
 * @brief Set the unit name.
 * @param nam Unit name.
 */
void SetName(const char * nam);

/**
 * @brief Get the unit ID.
 * @return Read-only pointer to the stored ID.
 */
const char * GetId() const;

/**
 * @brief Set the unit ID.
 * @param unitId Unit identifier.
 */
void SetId(const char * unitId);

  // These operators have been made friends. They have
  // privileged access to class internals.
  // Very useful for debugging the class, but not very good for class design.
  // We will keep using it for now but you will have a chance in a later lab
  // to redesign this class.
/**
 * @brief Read the unit ID, name and credits.
 * @param input Input stream.
 * @param C Unit to populate.
 * @return Input stream.
 */
friend istream & operator >>(istream & input, Unit & C);

/**
 * @brief Write the unit ID, name and credits.
 * @param os Output stream.
 * @param C Unit to display.
 * @return Output stream.
 */
friend ostream & operator <<(ostream & os, const Unit & C);

private:
    char name[CourseNameSize]; ///< Unit name.
    char id[10];              ///< Unit identifier.
    int credits;              ///< Number of credits.

// No implementation (code body) should be found after the line }; above.
// See topic 1 reading “Absolute C++. Pages 284-293. Separate
// Implementation/Interface. Structs vs Classes” available from My Unit Readings

// A .h file is interface or header file. Implementation should exist in
// the implementation file. Implementation file have .cpp extensions.
// Implementation is the body of the routine/method
// Concept is the same as what you did in ict159.
// So the following implementation needs to be moved to the corresponding
// implementation file (course.cpp)

// The method is inlined only if you have empirical evidence that inline would
// improve the run-time execution speed. Without this evidence, where should the
// following code be moved to?


};

#endif
